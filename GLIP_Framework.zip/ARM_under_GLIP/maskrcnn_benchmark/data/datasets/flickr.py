import torch
import torchvision
import torch.utils.data as data
from maskrcnn_benchmark.data.datasets.modulated_coco import ModulatedDataset


class FlickrDataset(ModulatedDataset):
    pass
