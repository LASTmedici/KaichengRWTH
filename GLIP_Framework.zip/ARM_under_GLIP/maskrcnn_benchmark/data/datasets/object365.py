import torch
import torchvision
import torch.utils.data as data
from maskrcnn_benchmark.data.datasets.coco_dt import CocoDetectionTSV


class Object365DetectionTSV(CocoDetectionTSV):
    pass
